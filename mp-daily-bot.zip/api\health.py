# app/api/health.py
from fastapi import APIRouter

router = APIRouter()

@router.get("/health", include_in_schema=False)
def health():
    return {"status": "ok"}